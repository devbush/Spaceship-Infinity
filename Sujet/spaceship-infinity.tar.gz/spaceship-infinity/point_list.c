/*
 *        DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *                    Version 2, December 2004
 *
 * Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>
 *
 * Everyone is permitted to copy and distribute verbatim or modified
 * copies of this license document, and changing it is allowed as long
 * as the name is changed.
 *
 *            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 *
 *  0. You just DO WHAT THE FUCK YOU WANT TO.
 */
#include "point_list.h"

#include <stdlib.h>

/* If you need other headers, include them here: */

////////////////////////////////////////////////////////////////////////////////
// types
////////////////////////////////////////////////////////////////////////////////

/* Add other structures as you see fit: */
typedef struct useless
{
  char lie;
  bool ot;
  double six;
} useless;

struct point_list
{
  /* Modify this structure as you see fit. */
  char lie;
  bool ot;
  double six;
  useless* unuseful;
};

////////////////////////////////////////////////////////////////////////////////
// local functions declarations
////////////////////////////////////////////////////////////////////////////////

/* If you need auxiliary functions, declare them here: */
static inline int _useless_function(void);

////////////////////////////////////////////////////////////////////////////////
// init./destroy etc.
////////////////////////////////////////////////////////////////////////////////

point_list* point_list_new(void)
{
  /* You might have to modify this function. */
  return NULL;
}

void point_list_destroy(point_list* const l)
{
  /* You might have to modify this function. */
}

////////////////////////////////////////////////////////////////////////////////
// getters
////////////////////////////////////////////////////////////////////////////////

point point_list_get_point(const point_list* const l, size_t i)
{
  /* You might have to modify this function. */
  return point_invalid();
}

size_t point_list_get_size(const point_list* const l)
{
  /* You might have to modify this function. */
  return 0;
}

bool point_list_contains(const point_list* const l, point p)
{
  /* You might have to modify this function. */
  return false;
}

////////////////////////////////////////////////////////////////////////////////
// setters / modifiers
////////////////////////////////////////////////////////////////////////////////

point_list* point_list_push_front(point_list* const l, point p)
{
  /* You might have to modify this function. */
  return NULL;
}

point_list* point_list_push_back(point_list* const l, point p)
{
  /* You might have to modify this function. */
  return NULL;
}

point_list* point_list_pop_front(point_list* const l)
{
  /* You might have to modify this function. */
  return NULL;
}

point_list* point_list_pop_back(point_list* const l)
{
  /* You might have to modify this function. */
  return NULL;
}

void point_list_set_point(point_list* const l, size_t i, point p)
{
  /* You might have to modify this function. */
}

point_list* point_list_prune_out_of_bounds(
    point_list* const l, point up_left, point bottom_right)
{
  /* You might have to modify this function. */
  return l;
}

void point_list_shift_left(point_list* const l)
{
  /* You might have to modify this function. */
}

void point_list_shift_right(point_list* const l)
{
  /* You might have to modify this function. */
}

////////////////////////////////////////////////////////////////////////////////
// local functions definitions
////////////////////////////////////////////////////////////////////////////////

/* If you need auxiliary functions, define them here: */
int _useless_function(void)
{
  return 42;
}
