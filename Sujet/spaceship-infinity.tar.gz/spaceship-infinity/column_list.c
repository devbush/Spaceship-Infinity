/*
 *        DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *                    Version 2, December 2004
 *
 * Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>
 *
 * Everyone is permitted to copy and distribute verbatim or modified
 * copies of this license document, and changing it is allowed as long
 * as the name is changed.
 *
 *            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
 *   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
 *
 *  0. You just DO WHAT THE FUCK YOU WANT TO.
 */
#include "column_list.h"

#include <stdlib.h>

/* If you need other headers, include them here: */

////////////////////////////////////////////////////////////////////////////////
// types
////////////////////////////////////////////////////////////////////////////////

/* Add other structures as you see fit: */
typedef struct useless
{
  char lie;
  double six;
} useless;

struct column_list
{
  /* Modify this structure as you see fit. */
  char lie;
  double six;
  useless* unuseful;
};

////////////////////////////////////////////////////////////////////////////////
// local functions declarations
////////////////////////////////////////////////////////////////////////////////

/* If you need auxiliary functions, declare them here: */
static inline int _useless_function(void);

////////////////////////////////////////////////////////////////////////////////
// init./destroy etc.
////////////////////////////////////////////////////////////////////////////////

column_list* column_list_new(void)
{
  /* You might have to modify this function. */
  return NULL;
}

void column_list_destroy(column_list* const l)
{
  /* You might have to modify this function. */
}

////////////////////////////////////////////////////////////////////////////////
// getters
////////////////////////////////////////////////////////////////////////////////

column* column_list_get_column(const column_list* const l, const size_t i)
{
  /* You might have to modify this function. */
  return NULL;
}

size_t column_list_get_size(const column_list* const l)
{
  /* You might have to modify this function. */
  return 0;
}

////////////////////////////////////////////////////////////////////////////////
// setters / modifiers
////////////////////////////////////////////////////////////////////////////////

column_list* column_list_push_front(column_list* const l, column* const c)
{
  /* You might have to modify this function. */
  return l;
}

column_list* column_list_push_back(column_list* const l, column* const c)
{
  /* You might have to modify this function. */
  return l;
}

column_list* column_list_pop_front(column_list* const l)
{
  /* You might have to modify this function. */
  return l;
}

column_list* column_list_pop_back(column_list* const l)
{
  /* You might have to modify this function. */
  return l;
}

////////////////////////////////////////////////////////////////////////////////
// local functions definitions
////////////////////////////////////////////////////////////////////////////////

/* If you need auxiliary functions, define them here: */
int _useless_function(void)
{
  return 42;
}
